package candidate

import (
	"context"
	"encoding/json"
	"errors"

	"github.com/XUJiahua/enterprise_agent/internal/app"
	"github.com/XUJiahua/enterprise_agent/internal/ledger"
	"github.com/XUJiahua/enterprise_agent/internal/protocol"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

const opCountersign = "countersign.v6"

// newCountersign serves the second approval of a purchase above the approval tier.
func newCountersign(pool *pgxpool.Pool) protocol.ConfirmHandler {
	return func(ctx context.Context, u app.Identity, key, id string, amount int) (protocol.ItemResult, bool, error) {
		tx, err := pool.Begin(ctx)
		if err != nil {
			return protocol.ItemResult{}, false, err
		}
		defer tx.Rollback(ctx)
		if _, err = tx.Exec(ctx, `SELECT set_config('app.tenant',$1,true),set_config('app.user',$2,true),set_config('app.role',$3,true)`, u.Tenant, u.User, u.Role); err != nil {
			return protocol.ItemResult{}, false, err
		}
		lock, _ := json.Marshal([]string{opCountersign, u.Tenant, u.User, key})
		if _, err = tx.Exec(ctx, `SELECT pg_advisory_xact_lock(hashtextextended($1,0))`, string(lock)); err != nil {
			return protocol.ItemResult{}, false, err
		}
		hash := ledger.Fingerprint(opCountersign, []string{id})
		var savedHash string
		var saved []byte
		err = tx.QueryRow(ctx, `SELECT "requestHash",response FROM "ActionRequest" WHERE "tenantId"=$1 AND "actorId"=$2 AND operation=$3 AND key=$4`,
			u.Tenant, u.User, opCountersign, key).Scan(&savedHash, &saved)
		if err == nil {
			if savedHash != hash {
				return protocol.ItemResult{}, false, &protocol.Rejection{Status: 409}
			}
			var stored protocol.ItemResult
			if err = json.Unmarshal(saved, &stored); err != nil {
				return protocol.ItemResult{}, false, err
			}
			return stored, true, tx.Commit(ctx)
		}
		if !errors.Is(err, pgx.ErrNoRows) {
			return protocol.ItemResult{}, false, err
		}
		var creator, status, first string
		var current int
		err = tx.QueryRow(ctx, `SELECT p."createdBy",p.status,p.amount,COALESCE((SELECT a."approvedBy" FROM "ApprovalAudit" a
		 WHERE a."tenantId"=p."tenantId" AND a."purchaseId"=p.id AND a."toStatus"='pending-second' ORDER BY a."createdAt" DESC LIMIT 1),'')
		 FROM "Purchase" p WHERE p.id=$1 AND p."tenantId"=$2 FOR UPDATE OF p`, id, u.Tenant).Scan(&creator, &status, &current, &first)
		if errors.Is(err, pgx.ErrNoRows) || (err == nil && (creator == u.User || status != "pending-second" || first == u.User || current != amount)) {
			return protocol.ItemResult{}, false, &protocol.Rejection{Status: 409}
		}
		if err != nil {
			return protocol.ItemResult{}, false, err
		}
		tag, err := tx.Exec(ctx, `UPDATE "Purchase" SET status='approved' WHERE id=$1 AND "tenantId"=$2 AND "createdBy"<>$3 AND status='pending-second'`, id, u.Tenant, u.User)
		if err != nil {
			return protocol.ItemResult{}, false, err
		}
		if tag.RowsAffected() != 1 {
			return protocol.ItemResult{}, false, &protocol.Rejection{Status: 409}
		}
		if _, err = tx.Exec(ctx, `INSERT INTO "ApprovalAudit" ("tenantId","purchaseId","approvedBy",operation,"idempotencyKey","fromStatus","toStatus") VALUES ($1,$2,$3,$4,$5,'pending-second','approved')`,
			u.Tenant, id, u.User, opCountersign, key); err != nil {
			return protocol.ItemResult{}, false, err
		}
		if _, err = tx.Exec(ctx, `INSERT INTO "PurchaseEvent" ("tenantId","purchaseId",type,"actorId","idempotencyKey") VALUES ($1,$2,'purchase.countersigned',$3,$4)`,
			u.Tenant, id, u.User, key); err != nil {
			return protocol.ItemResult{}, false, err
		}
		result := protocol.ItemResult{ID: id, Status: "approved"}
		response, err := json.Marshal(result)
		if err != nil {
			return protocol.ItemResult{}, false, err
		}
		if _, err = tx.Exec(ctx, `INSERT INTO "ActionRequest" ("tenantId","actorId",operation,key,"requestHash",response) VALUES ($1,$2,$3,$4,$5,$6::jsonb)`,
			u.Tenant, u.User, opCountersign, key, hash, string(response)); err != nil {
			return protocol.ItemResult{}, false, err
		}
		if err = tx.Commit(ctx); err != nil {
			return protocol.ItemResult{}, false, err
		}
		return result, false, nil
	}
}
