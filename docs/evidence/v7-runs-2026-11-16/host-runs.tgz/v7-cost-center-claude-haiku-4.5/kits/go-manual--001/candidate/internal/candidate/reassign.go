package candidate

import (
	"context"
	"encoding/json"
	"errors"
	"strings"

	"github.com/XUJiahua/enterprise_agent/internal/app"
	"github.com/XUJiahua/enterprise_agent/internal/ledger"
	"github.com/XUJiahua/enterprise_agent/internal/protocol"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

const opReassign = "bulk-reassign.v6"

// newReassign serves the approver-side bulk change of Purchase.assigneeId.
func newReassign(pool *pgxpool.Pool) protocol.AssignHandler {
	return func(ctx context.Context, u app.Identity, key string, ids []string, assignee string) (protocol.AssignResult, bool, error) {
		for _, id := range ids {
			if strings.ContainsRune(id, 0) {
				return protocol.AssignResult{}, false, &protocol.Rejection{Status: 404}
			}
		}
		tx, err := pool.Begin(ctx)
		if err != nil {
			return protocol.AssignResult{}, false, err
		}
		defer tx.Rollback(ctx)
		if _, err = tx.Exec(ctx, `SELECT set_config('app.tenant',$1,true),set_config('app.user',$2,true),set_config('app.role',$3,true)`, u.Tenant, u.User, u.Role); err != nil {
			return protocol.AssignResult{}, false, err
		}
		lock, _ := json.Marshal([]string{opReassign, u.Tenant, u.User, key})
		if _, err = tx.Exec(ctx, `SELECT pg_advisory_xact_lock(hashtextextended($1,0))`, string(lock)); err != nil {
			return protocol.AssignResult{}, false, err
		}
		hash := ledger.Fingerprint(opReassign+"\n"+assignee, ids)
		var savedHash string
		var saved []byte
		err = tx.QueryRow(ctx, `SELECT "requestHash",response FROM "ActionRequest" WHERE "tenantId"=$1 AND "actorId"=$2 AND operation=$3 AND key=$4`,
			u.Tenant, u.User, opReassign, key).Scan(&savedHash, &saved)
		switch {
		case err == nil && savedHash != hash:
			return protocol.AssignResult{}, false, &protocol.Rejection{Status: 409}
		case err == nil:
			var body struct {
				IDs      []string `json:"reassignedIds"`
				Assignee string   `json:"assignee"`
			}
			if err = json.Unmarshal(saved, &body); err != nil {
				return protocol.AssignResult{}, false, err
			}
			return protocol.AssignResult{Field: "reassignedIds", IDs: body.IDs, Assignee: body.Assignee}, true, tx.Commit(ctx)
		case !errors.Is(err, pgx.ErrNoRows):
			return protocol.AssignResult{}, false, err
		}
		// An unknown, other-tenant, requester or inactive assignee is refused like an ineligible target.
		var member bool
		if err = tx.QueryRow(ctx, `SELECT EXISTS (SELECT 1 FROM "TenantMember" WHERE "tenantId"=$1 AND "userId"=$2 AND role='approver' AND active)`,
			u.Tenant, assignee).Scan(&member); err != nil {
			return protocol.AssignResult{}, false, err
		}
		if !member {
			return protocol.AssignResult{}, false, &protocol.Rejection{Status: 409}
		}
		rows, err := tx.Query(ctx, `SELECT id,"assigneeId" FROM "Purchase" WHERE id=ANY($1::text[]) AND "tenantId"=$2 AND "createdBy"<>$3 AND status='submitted' ORDER BY id COLLATE "C" FOR UPDATE`,
			ids, u.Tenant, u.User)
		if err != nil {
			return protocol.AssignResult{}, false, err
		}
		previous := []*string{}
		for rows.Next() {
			var id string
			var old *string
			if err = rows.Scan(&id, &old); err != nil {
				rows.Close()
				return protocol.AssignResult{}, false, err
			}
			previous = append(previous, old)
		}
		err = rows.Err()
		rows.Close()
		if err != nil {
			return protocol.AssignResult{}, false, err
		}
		// Ineligible targets (missing, other tenant, own or not submitted) all get the same
		// 409; unlike the legacy per-purchase handlers in internal/app, Actions never reveal existence.
		if len(previous) != len(ids) {
			return protocol.AssignResult{}, false, &protocol.Rejection{Status: 409}
		}
		if _, err = tx.Exec(ctx, `UPDATE "Purchase" SET "assigneeId"=$4 WHERE id=ANY($1::text[]) AND "tenantId"=$2 AND "createdBy"<>$3 AND status='submitted'`,
			ids, u.Tenant, u.User, assignee); err != nil {
			return protocol.AssignResult{}, false, err
		}
		batch := &pgx.Batch{}
		for i, id := range ids {
			batch.Queue(`INSERT INTO "AssignmentHistory" ("tenantId","purchaseId","fromAssignee","toAssignee","changedBy",operation,"idempotencyKey") VALUES ($1,$2,$3,$4,$5,$6,$7)`,
				u.Tenant, id, previous[i], assignee, u.User, opReassign, key)
			batch.Queue(`INSERT INTO "PurchaseEvent" ("tenantId","purchaseId",type,"actorId","idempotencyKey") VALUES ($1,$2,'purchase.reassigned',$3,$4)`,
				u.Tenant, id, u.User, key)
		}
		result := protocol.AssignResult{Field: "reassignedIds", IDs: ids, Assignee: assignee}
		response, err := json.Marshal(result)
		if err != nil {
			return protocol.AssignResult{}, false, err
		}
		batch.Queue(`INSERT INTO "ActionRequest" ("tenantId","actorId",operation,key,"requestHash",response) VALUES ($1,$2,$3,$4,$5,$6::jsonb)`,
			u.Tenant, u.User, opReassign, key, hash, string(response))
		if err = tx.SendBatch(ctx, batch).Close(); err != nil {
			return protocol.AssignResult{}, false, err
		}
		if err = tx.Commit(ctx); err != nil {
			return protocol.AssignResult{}, false, err
		}
		return result, false, nil
	}
}
