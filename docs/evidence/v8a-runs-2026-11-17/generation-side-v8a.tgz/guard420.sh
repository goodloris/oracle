#!/bin/bash
# Replacement budget guard (prereg v8a appendix B): identical logic, threshold 420.
ROOT=/Users/administrator/poc-v8a-runs/v8a; BUDGET=420; LOG=$ROOT/driver.log; STOP=$ROOT/STOP
credits() { python3 - "$ROOT" <<'PY'
import glob, json, sys
t = 0.0
for f in glob.glob(sys.argv[1] + '/*/results/*/outcome.json'):
    u = (json.load(open(f)).get('generation') or {}).get('usage') or {}
    t += u.get('credits') or 0
print(round(t, 3))
PY
}
echo "$(date -u +%FT%TZ) guard replaced: budget $BUDGET (prereg v8a appendix B)" >> "$LOG"
while pgrep -f "run_v8a.sh $ROOT" >/dev/null; do
  c=$(credits); if python3 -c "import sys;sys.exit(0 if float('$c')>=float('$BUDGET') else 1)"; then
    touch "$STOP"; echo "$(date -u +%FT%TZ) BUDGET reached ($c >= $BUDGET): stopping lanes" >> "$LOG"
    pkill -f "generate.sh $ROOT/"; break; fi
  sleep 60; done
